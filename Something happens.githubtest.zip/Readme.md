Something Happens

Work in progress.  Started 01262017
See filelist.txt for file uses
See changelog.txt for notes, changes, giant unorganized mess
See Reddit "Changelog system.  Feedback requested.  Github test." to comment about all this

Respectfully,

Curl Out